package action;

/**
 * Created by Seven on 2017/3/2.
 */
public class HostelRegisterAction extends BaseAction {
}
