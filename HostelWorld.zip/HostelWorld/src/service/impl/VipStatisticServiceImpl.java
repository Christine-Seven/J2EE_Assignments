package service.impl;

import model.VipStaVO;
import org.springframework.stereotype.Service;
import service.VipStatisticService;

/**
 * Created by Seven on 2017/2/25.
 */
@Service
public class VipStatisticServiceImpl implements VipStatisticService {


    @Override
    public VipStaVO getVipStaInfo(String vipNum) {
        return null;
    }
}
