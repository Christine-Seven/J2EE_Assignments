package util;

/**
 * Created by Seven on 2017/2/21.
 */
public enum SettleConditionEnum {
    settled,wait
}
