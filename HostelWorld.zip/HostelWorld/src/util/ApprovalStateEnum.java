package util;

/**
 * Created by Seven on 2017/2/22.
 */
public enum ApprovalStateEnum {
    approve,disapprove,wait
}
