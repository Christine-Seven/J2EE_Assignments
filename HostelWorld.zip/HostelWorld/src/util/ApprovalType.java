package util;

/**
 * Created by Seven on 2017/2/24.
 */
public enum ApprovalType {
    register,modify
}
