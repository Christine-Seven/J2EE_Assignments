package util;

/**
 * Created by Seven on 2017/2/21.
 */
public enum OrderConditionEnum {
    book,checkin,checkout,overdue,cancel,valid,settle
    //已预订、已交订金、已入住、已离店、过期、取消、已结算
}
