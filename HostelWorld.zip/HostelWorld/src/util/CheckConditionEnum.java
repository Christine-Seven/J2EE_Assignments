package util;

/**
 * Created by Seven on 2017/2/21.
 */
public enum CheckConditionEnum {
    checkin,chechout
}
