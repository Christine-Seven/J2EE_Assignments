package util;

/**
 * Created by Seven on 2017/2/22.
 */
public enum VipStateEnum {
    register,activate,suspend,cancel
}
