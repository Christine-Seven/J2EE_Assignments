package model;

/**
 * Created by Seven on 2017/2/23.
 */
public class VipStaVO {

}
