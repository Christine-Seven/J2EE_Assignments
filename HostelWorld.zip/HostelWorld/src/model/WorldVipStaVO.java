package model;

/**
 * Created by Seven on 2017/2/24.
 */
public class WorldVipStaVO {
}
